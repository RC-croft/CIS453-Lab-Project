import React, { Component } from "react";
 import controls from "./img/Manual_004.png";
class Controls extends Component {
  render() {
    return (
      <div>
        
        <img class="ctrls" src={controls} alt=""/>
 
        
      </div>
    );
  }
}
export default Controls;
import React, { Component } from "react";
 import controls from "./img/Manual_004.png";
class Controls extends Component {
  render() {
    return (
      <div>
        
        <p><img className="ctrls" src={controls} alt=""/></p>
 
        
      </div>
    );
  }
}
export default Controls;
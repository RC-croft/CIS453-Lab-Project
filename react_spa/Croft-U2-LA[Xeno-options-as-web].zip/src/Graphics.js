import React, { Component } from "react";
 
class Graphics extends Component {
  render() {
    return (
      <div>
        
      </div>
    );
  }
}
 
export default Graphics;